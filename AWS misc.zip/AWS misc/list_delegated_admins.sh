#!/bin/bash

aws organizations list-delegated-administrators --service-principal aws-artifact-account-sync.amazonaws.com
aws organizations list-delegated-administrators --service-principal backup.amazonaws.com
aws organizations list-delegated-administrators --service-principal cloudtrail.amazonaws.com
aws organizations list-delegated-administrators --service-principal compute-optimizer.amazonaws.com
aws organizations list-delegated-administrators --service-principal config-multiaccountsetup.amazonaws.com
aws organizations list-delegated-administrators --service-principal config.amazonaws.com
aws organizations list-delegated-administrators --service-principal cost-optimization-hub.bcm.amazonaws.com
aws organizations list-delegated-administrators --service-principal fms.amazonaws.com
aws organizations list-delegated-administrators --service-principal member.org.stacksets.cloudformation.amazonaws.com
aws organizations list-delegated-administrators --service-principal ram.amazonaws.com
aws organizations list-delegated-administrators --service-principal reporting.trustedadvisor.amazonaws.com
aws organizations list-delegated-administrators --service-principal securityhub.amazonaws.com
aws organizations list-delegated-administrators --service-principal ssm.amazonaws.com
aws organizations list-delegated-administrators --service-principal sso.amazonaws.com
