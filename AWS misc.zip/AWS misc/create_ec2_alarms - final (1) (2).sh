#!/bin/bash

# SNS topic ARN
SNS_ARN="arn:aws:sns:us-east-1:381491851176:Volume"

# List all EC2 instance IDs
INSTANCE_IDS=$(aws ec2 describe-instances --query "Reservations[*].Instances[*].InstanceId" --output text)

# List of instance IDs with SSM Agent installed
SSM_INSTANCE_IDS=$(aws ssm describe-instance-information --query "InstanceInformationList[*].InstanceId" --output text)

for INSTANCE_ID in $INSTANCE_IDS; do
  # Create CPUUtilization alarm
  aws cloudwatch put-metric-alarm \
    --alarm-name "HighCPU-${INSTANCE_ID}" \
    --metric-name CPUUtilization \
    --namespace AWS/EC2 \
    --statistic Average \
    --period 300 \
    --threshold 80 \
    --comparison-operator GreaterThanThreshold \
    --dimensions Name=InstanceId,Value=${INSTANCE_ID} \
    --evaluation-periods 2 \
    --alarm-actions ${SNS_ARN} \
    --treat-missing-data notBreaching \
    --unit Percent

  # Create StatusCheckFailed alarm
  aws cloudwatch put-metric-alarm \
    --alarm-name "StatusCheckFailed-${INSTANCE_ID}" \
    --metric-name StatusCheckFailed \
    --namespace AWS/EC2 \
    --statistic Average \
    --period 300 \
    --threshold 1 \
    --comparison-operator GreaterThanOrEqualToThreshold \
    --dimensions Name=InstanceId,Value=${INSTANCE_ID} \
    --evaluation-periods 2 \
    --alarm-actions ${SNS_ARN} \
    --treat-missing-data notBreaching

  # Check if instance has SSM Agent installed
  if [[ $SSM_INSTANCE_IDS == *"$INSTANCE_ID"* ]]; then
    # Create MemoryUtilization alarm
    aws cloudwatch put-metric-alarm \
      --alarm-name "HighMemory-${INSTANCE_ID}" \
      --metric-name mem_used_percent \
      --namespace CWAgent \
      --statistic Average \
      --period 300 \
      --threshold 80 \
      --comparison-operator GreaterThanThreshold \
      --dimensions Name=InstanceId,Value=${INSTANCE_ID} \
      --evaluation-periods 2 \
      --alarm-actions ${SNS_ARN} \
      --treat-missing-data notBreaching \
      --unit Percent

    # Create DiskSpaceUtilization alarm
    aws cloudwatch put-metric-alarm \
      --alarm-name "HighDisk-${INSTANCE_ID}" \
      --metric-name used_percent \
      --namespace CWAgent \
      --statistic Average \
      --period 300 \
      --threshold 80 \
      --comparison-operator GreaterThanThreshold \
      --dimensions Name=InstanceId,Value=${INSTANCE_ID} Name=path,Value=/ \
      --evaluation-periods 2 \
      --alarm-actions ${SNS_ARN} \
      --treat-missing-data notBreaching \
      --unit Percent
  fi

  echo "Alarms created for instance: $INSTANCE_ID"
done
